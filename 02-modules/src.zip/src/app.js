import Handlebars from 'handlebars';

import $ from 'jquery';

var ENTER_KEY = 13;
var ESCAPE_KEY = 27;

import {
  init,
  cacheElements,
  bindEvents,
  render,
  renderFooter,
  toggleAll,
  getActiveTodos,
  getCompletedTodos,
  getFilteredTodos,
  destroyCompleted,
  indexFromEl,
  create,
  toggle,
  edit,
  editKeyup,
  update,
  destroy
} from './appfunctions';

import {
  uuid,
  pluralize,
  store
} from './util';

init();

